{
  "execMap": {
    "ts": "ts-node"
  }
}